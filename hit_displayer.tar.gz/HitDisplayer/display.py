import Tkinter as tk
#from Tkinter import *
import ttk
import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2TkAgg
from matplotlib.figure import Figure
import matplotlib.patches as mpatches
import numpy as np
master = tk.Tk()
import sys
import glob
from csb.bio.io.hhpred import HHOutputParser
#import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt

LARGE_FONT= ("Verdana", 12)

SKIP_CORES = 0

cores = {
    "1zcd": [(9,118),(221,315)],
    "5a1s": [(48,167),(264,385)],
    "4bwz": [(3,110),(214,215)],
    "4n7w": [(1,87),(152,242)]
}

class displayer():

    def __init__(self, results, *args, **kwargs):
        
        #tk.Tk.__init__(self, *args, **kwargs)
        root = tk.Tk()
        self.root = root
        root.wm_title( "HHpreds ugly little bro")
        
        
        root.geometry('1000x500+0+0')
        container = tk.Frame(root)
        container.pack(side="top", fill="both", expand = True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        frame = HHplot(container,root,results)
        frame.grid(row=0, column=0, sticky="nsew")
#        self.show_frame(HHplot)


class HHplot(tk.Frame):

    def __init__(self, parent,controller, res):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Results for {}".format(res['name']), font=LARGE_FONT)
        label.pack(pady=10,padx=10)

        button1 = ttk.Button(self, text="Quit",
                            command=controller.quit)
        button1.pack()

        self.results = res
        counter = {}
        for h in res['hits']: counter[h.query_id] = counter.get(h.query_id,0) + 1
        scounter = {}
        for h in res['hits']: scounter[h.subject_id] = scounter.get(h.subject_id,0) + 1
        self.hits = sorted(res['hits'],key=lambda x:(counter[x.query_id],x.query_id), reverse=True)
#        print [h.query_id for h in self.hits]
#        exit()
        self.hit_ranges = []
        print "Short stats:\n{} query sequences matched against {} sequences".format(len(counter),len(scounter))

        print "Match histogram for query sequences"# (each dot represents up to 5 hits)"
        for s,c in sorted(counter.items(),key=lambda x: x[1]):
            print "{}(...)\t{}".format(s[:5],"."*c)
        print "\n\nMatch histogram for subject sequences"# (each dot represents up to 5 hits)"
        for s,c in sorted(scounter.items(),key=lambda x:x[1]):
            print "{}(...)\t{}".format(s[:5],"."*c) # (c/5) + ("." if c%5 else ""))

        def format_hit(hit):
            id1,id2,s,e,eval,f1,s1,f2,d1,s2,d2 = hit
            f = "{:17}: {:5} {} {:>5}\n{:17}: {:5} {} {:>5}\nE-value: {}".format(id1,f1,s1,f2,id2,d1,s2,d2,eval)
            return f

        def show(mn):
            """ mn = index in results """
            self.T.configure(state="normal")
            self.T.delete('1.0', tk.END)
            self.T.insert(tk.END,format_hit(self.hits[mn]))
            self.T.configure(state="disabled")
    
#"{}".format(self.results['hits'][0]))

        def in_hit(hidx,x,y):
            l,r,t,b = self.hit_ranges[hidx]
            return l<=x and r<=e and b-1 < y and y < t+1

        ## TODO: NEED res
        fig,ax = plt.subplots()
        def on_click(event):
            if event.inaxes is not None:
#                print event.xdata, event.ydata
                for h in xrange(len(self.hits)):
                    if in_hit(h,event.xdata, event.ydata):
                        show(h)
                    
            else:
                print 'Clicked ouside axes bounds but inside plot window'


        #fig.canvas.callbacks.connect('button_press_event', on_click)

        ax.set_xlim(-10, res['length']+10)
        
        plt.xticks(range(-10, res['length']+10, 20),rotation='vertical')
        
#        gora = 5*(len(res['hits'])+1)
#        org_gora = gora
#        ax.set_ylim(0, org_gora+5)

        PATCHES = []
        
#        ax.plot([0,res['length']],[gora,gora],linewidth=20)
        dol = 0
        for hidx,(ids,idq,s,e,eval,_,_,_,_,_,_) in enumerate(self.hits):
            color = "red" if eval < 0.00001 else "green"
        #    ax.plot([s,e],[gora,gora],color=color,linewidth=7,zorder=2)
            pmain = mpatches.Rectangle((s,dol),e-s,5,facecolor=color)
            ax.add_patch(pmain)
            """ax.text(s,gora,id)"""
            """if True: # not er0:
        #        ax.scatter(s, gora, marker='x', color=color, zorder=3,linewidth=10)
                path = [[s,gora+1],[s+5,gora],[s,gora-1]]
                arr = np.array(path)
                pmain = mpatches.Polygon(arr,True,facecolor="white")
                ax.add_patch(pmain)
            else:
                ax.plot([s,s],[0,gora],color="grey",zorder=1)
            if True: #not er1:
#                ax.scatter(e, gora, marker='x', color=color, zorder=3,linewidth=10)
                path = [[e,gora+1],[e-5,gora],[e,gora-1]]
                arr = np.array(path)
                pmain = mpatches.Polygon(arr,True,facecolor="white")
                ax.add_patch(pmain)
            else:
                ax.plot([e,e],[0,gora],color="grey",zorder=1)"""
            self.hit_ranges.append((s,e,dol+5,dol))
            if hidx>0 and self.hits[hidx-1].query_id == idq:
                dol += 5
            else:
                dol += 10
        dol += 10
        pmain = mpatches.Rectangle((0,dol),res['length'],10)
        ax.add_patch(pmain)
        ax.text(0,dol+10,res['name'])
                        

        ax.set_ylim(0, dol+20)
        
#        plt.savefig(res['name'] + "_cores.png")
#        plt.show()

#        text = tk.Text(self)
#        text.pack(side=tk.BOTTOM)
        self.S = tk.Scrollbar(self,orient=tk.HORIZONTAL)
        self.T = tk.Text(self, height=6, width=150,wrap=tk.NONE)
#        self.S.pack(side=tk.RIGHT, fill=tk.Y)
#        self.T.pack(side=tk.LEFT, fill=tk.Y)
        self.T.pack(side=tk.BOTTOM,fill=tk.X, expand=True)
        self.S.pack(side=tk.BOTTOM,fill=tk.X)
        self.S.config(command=self.T.xview)
        self.T.config(xscrollcommand=self.S.set)
        self.T.insert(tk.INSERT, "Nothing to see here...")
        self.T.configure(state="disabled")
        self.T.pack()


        

        canvas = FigureCanvasTkAgg(fig, self)
        canvas.show()
        canvas.mpl_connect('button_press_event',on_click)
        canvas.get_tk_widget().pack(side=tk.BOTTOM, fill=tk.BOTH, expand=True)

        toolbar = NavigationToolbar2TkAgg(canvas, self)
        toolbar.update()
        canvas._tkcanvas.pack(side=tk.TOP, fill=tk.BOTH, expand=True)


def coreToSeq(seq,seq_start,core_start):
    """ Given seq and index of the core in this sequence,
        return alignment index of the core"""
    core_start-=seq_start
    if core_start < 0:
        #raise IndexError("Core index is before match: {}".format(core_start))
        return (0,0)
    
    for i,s in enumerate(seq):
        if s not in ["-","."]:
            core_start -= 1
        if not core_start:
            return (i,1)
    else:
#        raise IndexError("Core index is after match: {}".format(core_start))
        return (len(seq)-1,0)

def seqToCore(seq,seq_index,seq_start):
    """ Given seq_index of the core limit in the matching sequence,
    returns the index of the expected core in the given seq"""

    prefix = seq[:seq_index].replace("-","").replace(".","")
#    print "TEST::",prefix,seq_start
    seq_start += len(prefix)
    return seq_start
    
    
def parse_results(HHRS):
    RESULTS = {'length':0,'hits':[],'name':""}
    
    parser = HHOutputParser(True)
    
    for hhr in HHRS:
        results = parser.parse_file(hhr)
        this=results._query_name
        RESULTS['name'] = this
        for hit in results:
            id = hit._id
            RESULTS['length'] = hit._qlength
            if hit._id==this:
                continue
            cs = cores[hit._id.split("_")[0].lower()]
            pfam_s = hit._qstart
            pfam_e = hit._qend
            pdb_s = hit._start
            pdb_e = hit._end
            pfam_seq = hit._alignment._msa['query'].sequence
            pdb_seq = hit._alignment._msa[hit._id].sequence

            #print SKIP_CORES #RESULTS
            if SKIP_CORES:
                RESULTS['hits'].append((id,(pfam_s,pfam_e),(0,0),hit._evalue,(pfam_s,pfam_seq,pfam_e,pdb_s,pdb_seq,pdb_e) ))
                continue

            if pdb_s < 100:
                cs = cs[0]
                id += "_0"
            else:
                cs = cs[1]
                id += "_1"
    
            #print "Query:",this, "Target",hit._id
            #print pfam_s, pfam_seq,pfam_e
            #print pdb_s, pdb_seq,pdb_e
    
            i,er0 = coreToSeq(pdb_seq,pdb_s,cs[0])
            j,er1 = coreToSeq(pdb_seq,pdb_s,cs[1])
            #print "Core",cs,i,j
            
            s = seqToCore(pfam_seq,i,pfam_s)
            e = seqToCore(pfam_seq,j,pfam_s)
            match = pfam_seq[i:j+1]
            #print "Match",match,s,e
    
            RESULTS['hits'].append((id,(s,e),(er0,er1),hit._evalue,(pfam_s+i,pfam_seq[i:j+1],pfam_s+j,pdb_s+i,pdb_seq[i:j+1],pdb_e+j) ))
    
            
            #print "{}\t{}\t{}".format(this, hit._id,hit._evalue)
            #print "======================###############============================"
    return RESULTS


if __name__ == "__main__":
    if len(sys.argv) < 2:
        exit("Usage:\n\tpython ./FastaExtractor.py full.fasta PF00001_connections_E_minus_5 > test_output"  )
    if sys.argv[1] == "1":
        SKIP_CORES = True
        #print "skipping core selection..."
        HHRS = sys.argv[2:]
    else:
        HHRS = glob.glob("*/"+sys.argv[1])
#    HHRS = glob.glob(sys.argv[1]+"*.hhr")
    #
    #print HHRS
    res = parse_results(HHRS)

    app = SeaofBTCapp(res)
    app.root.mainloop()

