import re
import BlastReader as BR
from collections import namedtuple
from display import displayer

Sequence = namedtuple("Sequence", "id seq")

def fastaReader(handle):
    id = seq = ""
    for line in handle:
        if line[0] == ">":
            if id: 
#                print id,seq
                yield id,seq
                seq = ''
            id = line.strip()[1:].split("/")[0]
        else:
            seq += line.strip()
    if seq:
#        print id,seq
        yield id,seq
        

def index_seq(seq):
    _ids = []
    for i,e in enumerate(seq):
        if e != "-": _ids.append(i)
    return _ids#,seq.replace("-","")

class FilteredFasta:
    def __init__(self, index_list, handle):
        # index_list is a list of tuples index,id_q,id_s
        self.sequences = {i[0]:[] for i in index_list}
        self.len = 0
        seq_gen = fastaReader(handle)
        for id,seq in seq_gen:
#            _trash = []
            for _id in index_list:
                if id in _id: 
                    self.sequences[_id[0]]  += [(id,seq,index_seq(seq))] #self.sequences.get(_id[0],[])
                self.len = len(seq)
#            while _trash:
#                index_list.pop(_trash.pop())



def get_matches(fasta_fname, blast_fname):
    with open(blast_fname) as bhandle:
        blast_hits = BR.HitList(bhandle)
    id_list = [(_,h.query.short_id,h.subject.short_id) for _,h in enumerate(blast_hits)]
    
    with open(fasta_fname) as fhandle:
        ref_seqs = FilteredFasta(id_list, fhandle)


#    print ref_seqs.sequences.items()[0]
#    exit()
    for k,v in ref_seqs.sequences.items():
        if v is not None:
            blast_hits[k].align2ref(v)
    

    profile = {}
    profile['length'] = ref_seqs.len
    profile['name'] = fasta_fname.split(".fa")[0]

    profile['hits'] = []
    ParsedHit = namedtuple("ParsedHit", "subject_id query_id ref_start ref_end eval sub_start sub_seq sub_end q_start q_seq q_end")
    for h in blast_hits:
        hit = ParsedHit(h.subject.short_id,h.query.short_id,h.ref_start,h.ref_end,h.eval,h.subject.start,h.subject.seq,h.subject.end,
                               h.query.start,h.query.seq,h.query.end)
        profile['hits'].append(hit)

#    profile['hits'] = [((h.subject.short_id,h.query.short_id), (h.ref_start,h.ref_end),(0,0),h.eval,
#                        (h.subject.start,h.subject.seq,h.subject.end,
#                        h.query.start,h.query.seq,h.query.end)) for h in blast_hits]

    app = displayer(profile)
    app.root.mainloop()

if __name__ == "__main__":
    import sys
    get_matches(sys.argv[1],sys.argv[2])
