import re
from Bio import pairwise2


class BadHit(Exception):
    pass

class HitSeq:
    id_pattern = re.compile("([A-Z0-9]+)_([A-Z0-9]+)[_/][0-9]+[_-][0-9]+")
    alt_id_pattern = re.compile("([A-Z0-9]+)_([A-Z0-9]+)$")
    def __init__(self,id,segment,patt):
        self.id = id.split()[0]
        try:
#        if "PF01699" in self.id: print self.id, id_pattern.findall(id)
            self.short_id = "_".join(HitSeq.id_pattern.findall(id)[0])
        except:
            try:
                self.short_id = "_".join(HitSeq.alt_id_pattern.findall(id)[0])
            except:
                self.short_id = self.id
        data = patt.findall(segment)
        if data:
            self.start = int(data[0][0])
            self.end = int(data[-1][-1])
            self.seq = "".join(_[1] for _ in data)
        else:
    #        print data,segment
            raise BadHit
    def align2ref(self,all_seqs):
        results = {}
        for id,seq,index in all_seqs:
            
            short_seq = seq.replace("-","")
            aln = pairwise2.align.globalms(short_seq,self.seq, 2, -1, -.5, -.1)
            for s1,s2,sc,_,_ in aln:
                results[sc] = (s1,s2,index)
        rs,hs,index = results[max(results.keys())]
#        print index
#        print rs
#        print hs

        _aseq = hs.strip("-")

        s = index[hs.index(_aseq)] + (0 if rs[0]!="-" else len(rs)-len(rs.lstrip("-")) )
        try:
            e = index[s+len(_aseq)-1]
        except:
            e = index[-1]
#        print all_seqs[0][0],s,e
        return s,e


class OneHit:
    pattern_1 = re.compile("E Value\s+([A-Z0-9a-z_/-]+)\s+([0-9.]+)\s+([0-9.e-]+)\s+Query= (.*?)\s+Length")
    pattern_2 = re.compile("Query\s+(\d+)\s+([A-Za-z-]+)\s+(\d+)")
    pattern_3 = re.compile("Sbjct\s+(\d+)\s+([A-Za-z-]+)\s+(\d+)")
    def __init__(self, segment):
        try:
            sid,score,eval,qid = OneHit.pattern_1.findall(segment)[0]
        except:
            raise BadHit(segment)
        self.score = float(score)
        self.eval = float(eval)
        self.query = HitSeq(qid,segment,OneHit.pattern_2)
        self.subject = HitSeq(sid,segment,OneHit.pattern_3)
        self.ref_start = None
        self.ref_end = None

    def align2ref(self,all_seqs):
        id = all_seqs[0][0]
#        print id,all_seqs
        if id == self.query.short_id:
            s,e = self.query.align2ref(all_seqs)#seq,index)
        else:
            s,e = self.subject.align2ref(all_seqs)#seq,index)
        self.ref_start = s
        self.ref_end = e

class HitList:
    def __init__(self, handle):
        self.hitlist = []
        for segment in re.split("#+",handle.read())[1:]:
            try:
                self.hitlist.append(OneHit(segment))
            except:
                pass
    def __getitem__(self,_):
        return self.hitlist[_]
    
    def __iter__(self):
        return iter(self.hitlist)

if __name__ == "__main__":
    import sys
    plik = sys.argv[1]
    with open(plik) as input:
        H = HitList(input)
    print H[0]
    for i in H:
        print i
        break
    print vars(H.hitlist[0].subject)
